import { test } from 'node:test';
import assert from 'node:assert/strict';
import serverless from 'serverless-http';
import { createApplication } from '../server';

const testKey = 'sf_live_u_123456789abc_0123456789abcdef01234567';
const app = await createApplication(false);
const handle = serverless(app);
async function request(path: string, key?: string, body?: any) {
  return handle({ httpMethod: body ? 'POST' : 'GET', path, headers: { 'Content-Type': 'application/json', ...(key ? { 'X-API-KEY': key } : {}) }, body: body ? JSON.stringify(body) : null, isBase64Encoded: false, requestContext: { identity: {} } }, {}) as Promise<any>;
}

test('function health routing works and does not return secrets', async () => {
  process.env.SERPFORGE_APPLICATION_KEY = testKey;
  const result = await request('/api/v1/health');
  assert.equal(result.statusCode, 200);
  assert.equal(JSON.parse(result.body).applicationKeyConfigured, true);
  assert.ok(!result.body.includes(testKey));
});
test('keyless and wrong-key requests fail before accessing data sources', async () => {
  assert.equal((await request('/api/v1/search', undefined, { q: 'Delhi' })).statusCode, 401);
  assert.equal((await request('/api/v1/search', 'wrong', { q: 'Delhi' })).statusCode, 401);
});
test('source verification failures stay errors and never turn into Wikipedia business results', async () => {
  const previous = globalThis.fetch;
  globalThis.fetch = (async (url: any) => String(url).includes('html.duckduckgo.com') ? new Response('<div class="anomaly-modal">Verification required</div>') : new Response('{}', { status: 503 })) as any;
  try {
    const result = await request('/api/v1/search', testKey, { q: 'Healthcare Delhi' });
    assert.equal(result.statusCode, 502);
    assert.match(JSON.parse(result.body).message, /verification/);
    assert.equal(JSON.parse(result.body).organic, undefined);
  } finally { globalThis.fetch = previous; }
});
test('live fixture results report the real search engine', async () => {
  const previous = globalThis.fetch;
  globalThis.fetch = (async (url: any) => String(url).includes('html.duckduckgo.com') ? new Response('<div class="result"><a class="result__a" href="https://school.example">Example School Delhi</a><span class="result__snippet">Official school website</span></div>') : new Response('{}', { status: 503 })) as any;
  try {
    const result = await request('/api/v1/search', testKey, { q: 'Example School Delhi' });
    assert.equal(result.statusCode, 200);
    const data = JSON.parse(result.body);
    assert.equal(data.searchParameters.engine, 'duckduckgo');
    assert.equal(data.organic[0].link, 'https://school.example');
  } finally { globalThis.fetch = previous; }
});
test('places require a configured upstream and preserve actual published contacts', async () => {
  delete process.env.SERPFORGE_PLACES_URL;
  assert.equal((await request('/api/v1/places', testKey, { q: 'Delhi clinics' })).statusCode, 502);
  const previous = globalThis.fetch;
  process.env.SERPFORGE_PLACES_URL = 'https://operator.example/search';
  globalThis.fetch = (async () => Response.json([{ place_id: 1, osm_type: 'node', osm_id: 123, name: 'Clinic', display_name: 'Clinic, Delhi', lat: '28.6', lon: '77.2', extratags: { 'contact:phone': '+911112345678', website: 'https://clinic.example' } }])) as any;
  try {
    const result = await request('/api/v1/places', testKey, { q: 'Delhi clinics' });
    const data = JSON.parse(result.body);
    assert.equal(data.searchParameters.engine, 'openstreetmap');
    assert.equal(data.places[0].phoneNumber, '+911112345678');
    assert.equal(data.places[0].website, 'https://clinic.example');
    assert.equal(data.places[0].sourceUrl, 'https://www.openstreetmap.org/node/123');
  } finally { globalThis.fetch = previous; delete process.env.SERPFORGE_PLACES_URL; }
});
test('stateless Netlify deployment cannot mint or revoke application keys', async () => {
  assert.equal((await request('/api/keys/mint', undefined, { name: 'New key' })).statusCode, 503);
  assert.equal((await request('/api/keys/revoke', undefined, { keyId: 'other-user-key' })).statusCode, 503);
});

test('Netlify rewrite prefix normalizes to the real API route', async () => {
  const { handler } = await import('../netlify/functions/api');
  const response: any = await handler({ httpMethod: 'GET', path: '/.netlify/functions/api/api/v1/health', headers: {}, body: null, isBase64Encoded: false, requestContext: { identity: {} } }, {});
  assert.equal(response.statusCode, 200);
  assert.equal(JSON.parse(response.body).status, 'ok');
});
