# Deploy the search backend, not only the console

This source contains both the SerpForge console and an Express API. The original static deployment has no API routes. The included netlify.toml and netlify/functions/api.ts deploy the API alongside the console. Connect this full source directory to the existing Netlify project and let Netlify run npm run build. A drag-and-drop dist-only upload cannot deploy Functions.

## Required server/function configuration

- SERPFORGE_APPLICATION_KEY: the existing application key supplied by the owner, stored privately in Netlify environment variables. Do not paste it into source, browser code or a VITE_ variable. This permits that application key on the repaired backend without relying on the old predictable signing secret.
- SERPFORGE_PLACES_URL: an HTTPS, operator-controlled or licensed Nominatim-compatible search endpoint. Generic search API reselling through public nominatim.openstreetmap.org violates its usage policy; this deployment does not default to that endpoint. See https://operations.osmfoundation.org/policies/nominatim/ . Self-hosting needs infrastructure and data; the API code cannot create a complete free business dataset.
- Node 24 is selected for compatibility with the supplied Firebase frontend dependencies.

Optional persistent Node hosting supports SERPFORGE_DATA_DIR and a strong, persistent private SERPFORGE_KEY_SECRET. Existing console key management routes are deliberately unavailable in stateless Netlify Functions; they return a configuration error instead of claiming revocation persists across cold starts. The application key is controlled by its server environment. Production Node key mint/revoke requires verified owner authentication; management behavior has not been exercised against a live Firebase account.

## Data truthfulness

Web results are parsed from public DuckDuckGo HTML, not Google. Verification challenges or upstream errors return a 502 error. No Wikipedia substitution is used for failed business searches. Successful empty results stay empty. Places are OpenStreetMap results from the configured upstream, with source URLs and phone/website tags only when returned by that source. No lab status or phone number is guessed. Search-engine blocking, source coverage and upstream terms still apply; this is not guaranteed unlimited lifetime access to Google or a proprietary directory.

## Verification after deployment

1. GET https://coruscating-faloodeh-5df271.netlify.app/api/v1/health must return JSON, with applicationKeyConfigured true and placesConfigured true when places are configured.
2. POST /api/v1/search and /api/v1/places with the X-API-KEY header and a JSON q field. Check sources and meaningful returned results. A working health route alone does not prove data coverage.
3. On the Natton application backend configure SERPFORGE_API_BASE_URL=https://coruscating-faloodeh-5df271.netlify.app/api/v1 and SERPFORGE_API_KEY to the same private application key. Set SERPFORGE_ENABLED=true only after authenticated endpoint checks pass. The original Serper key is retained.
4. Retry the business search and school checks. Schools still require matching school name/location and explicit official-site lab evidence; phones are marked found only from published sources.

Local checks: npm ci, npm run lint, npm test, npm run build. Automated tests use fixtures and do not prove the upstream public search is currently available. Live Netlify deployment and real-data verification require access to the hosting project and the configured source.
