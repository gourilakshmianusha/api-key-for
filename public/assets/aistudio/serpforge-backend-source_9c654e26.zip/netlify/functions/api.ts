import serverless from 'serverless-http';
import { createApplication } from '../../server';
let application: ReturnType<typeof createApplication> | undefined;
export const handler = async (event: any, context: any) => {
  application ||= createApplication(false);
  const normalized = { ...event, path: event.path?.replace(/^\/\.netlify\/functions\/api(?=\/)/, '') };
  return serverless(await application)(normalized, context);
};
